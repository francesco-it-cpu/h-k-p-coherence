import os
import sys
from anytree import search
import HKP_Anonymizer


def find_unique_items(input_file):
    with open(input_file, "r") as file:
        lines = file.read()
        unique_items = set(lines.split())

        return unique_items


# check if MM values in score table equal total mole_num count
# if there is inequality raises assertion error
def check_MM_equal_mole_num(tree_root, score_table):
    for index, item in enumerate(score_table.keys()):
        count = 0
        test_list = search.findall(tree_root, filter_=lambda node: node.label == item)
        for i in test_list:
            count += i.mole_num
        assert count == score_table[item][
            'MM'], f"{index} NOT EQUAL -- Item: {item}, Score_table MM: {score_table[item]['MM']}, " \
                   f"mole num count: {count}"


def prepare_data(data_path_pub,data_path_priv):

   # make a list of all items that can be found in the datasets
    pub_unique_items = find_unique_items(data_path_pub)
    priv_unique_items = find_unique_items(data_path_priv)
    
    pub_unique_items = [int(i) for i in pub_unique_items]
    priv_unique_items = [int(i) for i in priv_unique_items]
    
    public_items = pub_unique_items
    # determine the private items
    private_items = [i for i in priv_unique_items if i not in public_items]

    
    # read all the data from the text file
    dataset = []
    with open(data_path_pub, "r") as pub, open(data_path_priv,"r") as priv:
        for publ,privl in zip(pub,priv):
            line = publ.strip() + " " + privl.strip()
            dataset.append([int(i) for i in set(line.rstrip().split())])

    return dataset,public_items, private_items


def time_retriever(data_path_pub,data_path_priv,h,k_list,p_list):
    """
    Retrieve the time for each h,k,p combination in the k_list and p_list
    :param data_path_pub: path to the public data
    :param data_path_priv: path to the private data
    :param h: h value
    :param k_list: list of k values
    :param p_list: list of p values
    :return:
    """
    for k in k_list:
        for p in p_list:
            #enablePrint()
            print("h: {}, k: {}, p: {}".format(h,k,p))
            #blockPrint()
            dataset,public_items, private_items = prepare_data(data_path_pub,data_path_priv)
            hkp = HKP_Anonymizer.HKPCoherence(dataset, public_items, private_items,h,k=k,p=p)
            hkp.Execute_anonymization(check_verification=True)

def blockPrint():
    sys.stdout = open(os.devnull, 'w')

def enablePrint():
    sys.stdout = sys.__stdout__