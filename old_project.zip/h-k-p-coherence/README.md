# Usage
```
python3 main.py -hv 0.8 -k 2 -p 2 -dpub Dataset/pub.dat -dpriv Dataset/priv.dat
```

# Requirements
```
pip install numpy pandas anytree matplotlib
```

# To generate a Dataset
## The datasets will be written in Dataset/
```
python3 dataset_generator.py -row <number_rows> -pu <number_columns_pub> -pv <number_columns_priv>
```
