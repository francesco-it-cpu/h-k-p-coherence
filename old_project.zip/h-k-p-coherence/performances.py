import utils
import subprocess
import time

if __name__ == '__main__':

    data_path_pub = "Dataset/pub.dat"
    data_path_priv = "Dataset/priv.dat"

    pub_cmd = "awk -F' ' '{print NF; exit}' Dataset/pub.dat"
    priv_cmd = "awk -F' ' '{print NF; exit}' Dataset/priv.dat"

    pub_cols = int(subprocess.check_output(pub_cmd, shell=True))
    priv_cols = int(subprocess.check_output(priv_cmd, shell=True))

    print("Public dataset has {} columns".format(pub_cols))
    print("Private dataset has {} columns".format(priv_cols))
    
    H = 0.8
    p_list = [2,3,4, 5, 6, 7]
    k_list = [5,10, 20, 30, 40, 50]
    P_list = [4]
    K_list = [10]


    utils.time_retriever(data_path_pub,data_path_priv,H,K_list,P_list)