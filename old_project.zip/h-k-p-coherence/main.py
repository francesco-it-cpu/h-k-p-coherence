import argparse
import HKP_Anonymizer
import utils


def positive_int(s: str) -> int:
    try:
        value = int(s)
    except ValueError:
        raise argparse.ArgumentTypeError(f'expected integer, got {s!r}')

    if value < 0:
        raise argparse.ArgumentTypeError(f'expected positive integer, got {value}')

    return value


def percentage(s: str) -> float:
    try:
        value = float(s)
    except ValueError:
        raise argparse.ArgumentTypeError(f'expected float in range (0,1), got {s!r}')

    if 0 < value < 1:
        return value
    else:
        raise argparse.ArgumentTypeError(f'expected float in range (0,1), got {value}')


def main(args):
    h = args.hv
    k = args.k
    p = args.p
    data_path_pub = args.data_path_pub
    data_path_priv = args.data_path_priv
    verification_flag = args.no_verification

    dataset,public_items, private_items = utils.prepare_data(data_path_pub,data_path_priv)

    # create the hkp object
    hkp = HKP_Anonymizer.HKPCoherence(dataset,public_items, private_items, h, k, p)

    # start the anonymization process
    hkp.Execute_anonymization(check_verification=verification_flag)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Runs (h,k,p)-coherence algorithm',
                                     formatter_class=argparse.RawDescriptionHelpFormatter)

    parser.add_argument('-hv',
                        type=percentage,
                        default=0.4,
                        help='(0,1) percentage value. (default: %(default)s)')

    parser.add_argument('-k',
                        type=positive_int,
                        default=10,
                        help='enter the value of k, positive integer. (default: %(default)s)',
                        )

    parser.add_argument('-p',
                        type=positive_int,
                        default=4,
                        help='enter the value of p, positive integer. (default: %(default)s)'
                        )
    parser.add_argument('-dpub', '--data-path-pub',
                        type=str,
                        default='Dataset/Paper Example/pub.dat',
                        help='enter the path of the dataset. (default: %(default)s)'
                        )
    parser.add_argument('-dpriv', '--data-path-priv',
                        type=str,
                        default='Dataset/Paper Example/priv.dat',
                        help='enter the path of the dataset. (default: %(default)s)'
                        )

    parser.add_argument('--no-verification',
                        action='store_false',
                        default=True,
                        help='choose if you wanna run the anonymization verifier after anonymizing. '
                             '(default: %(default)s)',
                        )

    args = parser.parse_args()

    # run
    main(args)
